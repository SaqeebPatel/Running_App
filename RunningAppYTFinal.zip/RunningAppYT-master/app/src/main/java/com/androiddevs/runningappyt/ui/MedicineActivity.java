package com.androiddevs.runningappyt.ui;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.androiddevs.runningappyt.R;

public class MedicineActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_medicine);
    }
}