package com.androiddevs.runningappyt.di;

import android.content.DialogInterface;

public interface OnDialogCloseListener {

    void onDialogClose(DialogInterface dialogInterface);
}
